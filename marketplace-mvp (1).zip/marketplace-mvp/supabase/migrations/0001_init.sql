-- ============================================================================
-- MARKETPLACE MVP — INITIAL SCHEMA
-- Multi-vendor catalog: buyers, vendors (sellers), categories, products,
-- orders split per-vendor, reviews, cart.
--
-- This file already includes the fixes Supabase's own security/performance
-- advisor (get_advisors) flagged when this was first deployed:
--   - handle_new_user() has EXECUTE revoked from anon/authenticated/public,
--     since it's only meant to run as the auth.users trigger.
--   - RLS policies wrap auth.uid() as (select auth.uid()) so Postgres
--     evaluates it once per statement instead of once per row.
--   - product_images has separate insert/update/delete policies instead of
--     one "for all", so it doesn't double up with the public-read policy.
--   - Every foreign key has a covering index.
-- Run this once in the Supabase SQL editor (or via `supabase db push`).
-- ============================================================================

create extension if not exists "uuid-ossp";

-- ----------------------------------------------------------------------------
-- PROFILES — one row per auth user (buyer, vendor-owner, or admin)
-- ----------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  phone text,
  role text not null default 'buyer' check (role in ('buyer', 'vendor', 'admin')),
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever someone signs up via Supabase Auth.
-- This must only ever run as the trigger below — never as a public RPC —
-- so EXECUTE is revoked from anon/authenticated/public further down.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data ->> 'full_name');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- ----------------------------------------------------------------------------
-- VENDORS — each seller's storefront
-- ----------------------------------------------------------------------------
create table vendors (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  slug text not null unique,
  description text,
  logo_url text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'suspended')),
  rating numeric(2, 1) not null default 0,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- CATEGORIES — self-referencing tree (top-level categories have parent_id null)
-- ----------------------------------------------------------------------------
create table categories (
  id uuid primary key default uuid_generate_v4(),
  parent_id uuid references categories(id) on delete cascade,
  name text not null,
  slug text not null unique,
  image_url text,
  sort_order int not null default 0
);

-- ----------------------------------------------------------------------------
-- PRODUCTS
-- ----------------------------------------------------------------------------
create table products (
  id uuid primary key default uuid_generate_v4(),
  vendor_id uuid not null references vendors(id) on delete cascade,
  category_id uuid not null references categories(id),
  name text not null,
  slug text not null unique,
  description text,
  price numeric(12, 2) not null check (price >= 0),
  compare_at_price numeric(12, 2),
  stock_quantity int not null default 0,
  status text not null default 'draft' check (status in ('draft', 'active', 'archived')),
  attributes jsonb not null default '{}',
  rating numeric(2, 1) not null default 0,
  reviews_count int not null default 0,
  created_at timestamptz not null default now()
);

create table product_images (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references products(id) on delete cascade,
  url text not null,
  sort_order int not null default 0
);

-- ----------------------------------------------------------------------------
-- ADDRESSES
-- ----------------------------------------------------------------------------
create table addresses (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  full_name text not null,
  phone text not null,
  city text not null,
  postal_code text,
  line1 text not null,
  is_default boolean not null default false
);

-- ----------------------------------------------------------------------------
-- CART — persisted so it survives across devices/sessions
-- ----------------------------------------------------------------------------
create table cart_items (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references profiles(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  quantity int not null default 1 check (quantity > 0),
  created_at timestamptz not null default now(),
  unique (user_id, product_id)
);

-- ----------------------------------------------------------------------------
-- ORDERS — one order per checkout, split into per-vendor groups for fulfillment
-- (a single cart can contain products from several vendors, like on Rozetka)
-- ----------------------------------------------------------------------------
create table orders (
  id uuid primary key default uuid_generate_v4(),
  buyer_id uuid not null references profiles(id),
  address_id uuid references addresses(id),
  status text not null default 'pending' check (status in ('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled')),
  total_amount numeric(12, 2) not null default 0,
  created_at timestamptz not null default now()
);

create table order_vendor_groups (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  vendor_id uuid not null references vendors(id),
  status text not null default 'pending' check (status in ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  subtotal numeric(12, 2) not null default 0
);

create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_vendor_group_id uuid not null references order_vendor_groups(id) on delete cascade,
  product_id uuid not null references products(id),
  quantity int not null check (quantity > 0),
  unit_price numeric(12, 2) not null
);

-- ----------------------------------------------------------------------------
-- REVIEWS
-- ----------------------------------------------------------------------------
create table reviews (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references products(id) on delete cascade,
  user_id uuid not null references profiles(id),
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique (product_id, user_id)
);

-- ----------------------------------------------------------------------------
-- INDEXES — one per foreign key, so lookups in either direction stay fast
-- ----------------------------------------------------------------------------
create index idx_products_category on products(category_id);
create index idx_products_vendor on products(vendor_id);
create index idx_products_status on products(status);
create index idx_categories_parent on categories(parent_id);
create index idx_product_images_product on product_images(product_id);
create index idx_order_items_group on order_items(order_vendor_group_id);
create index idx_reviews_product on reviews(product_id);
create index idx_addresses_user on addresses(user_id);
create index idx_cart_items_product on cart_items(product_id);
create index idx_order_items_product on order_items(product_id);
create index idx_order_vendor_groups_order on order_vendor_groups(order_id);
create index idx_order_vendor_groups_vendor on order_vendor_groups(vendor_id);
create index idx_orders_address on orders(address_id);
create index idx_orders_buyer on orders(buyer_id);
create index idx_reviews_user on reviews(user_id);
create index idx_vendors_owner on vendors(owner_id);

-- ============================================================================
-- ROW LEVEL SECURITY
-- Every table is locked down by default; policies below open the exact
-- access each role needs. auth.uid() is wrapped as (select auth.uid()) so
-- Postgres evaluates it once per statement, not once per row.
-- ============================================================================

alter table profiles enable row level security;
create policy "Profiles are viewable by everyone" on profiles for select using (true);
create policy "Users update own profile" on profiles for update using ((select auth.uid()) = id);

alter table vendors enable row level security;
create policy "Approved vendors are public, owners see their own" on vendors
  for select using (status = 'approved' or owner_id = (select auth.uid()));
create policy "Users can open their own vendor storefront" on vendors
  for insert with check ((select auth.uid()) = owner_id);
create policy "Owners manage their vendor" on vendors
  for update using ((select auth.uid()) = owner_id);

alter table categories enable row level security;
create policy "Categories are public" on categories for select using (true);

alter table products enable row level security;
create policy "Active products are public, vendors see their own drafts" on products
  for select using (
    status = 'active'
    or vendor_id in (select id from vendors where owner_id = (select auth.uid()))
  );
create policy "Vendors add products to their own store" on products
  for insert with check (vendor_id in (select id from vendors where owner_id = (select auth.uid())));
create policy "Vendors edit their own products" on products
  for update using (vendor_id in (select id from vendors where owner_id = (select auth.uid())));
create policy "Vendors delete their own products" on products
  for delete using (vendor_id in (select id from vendors where owner_id = (select auth.uid())));

alter table product_images enable row level security;
create policy "Product images are public" on product_images for select using (true);
create policy "Vendors add images to their own products" on product_images
  for insert with check (
    product_id in (select id from products where vendor_id in (select id from vendors where owner_id = (select auth.uid())))
  );
create policy "Vendors update images on their own products" on product_images
  for update using (
    product_id in (select id from products where vendor_id in (select id from vendors where owner_id = (select auth.uid())))
  );
create policy "Vendors delete images on their own products" on product_images
  for delete using (
    product_id in (select id from products where vendor_id in (select id from vendors where owner_id = (select auth.uid())))
  );

alter table addresses enable row level security;
create policy "Users manage their own addresses" on addresses for all using (user_id = (select auth.uid()));

alter table cart_items enable row level security;
create policy "Users manage their own cart" on cart_items for all using (user_id = (select auth.uid()));

alter table orders enable row level security;
create policy "Buyers see their own orders" on orders for select using (buyer_id = (select auth.uid()));
create policy "Buyers create their own orders" on orders for insert with check (buyer_id = (select auth.uid()));

alter table order_vendor_groups enable row level security;
create policy "Buyer or vendor can see their side of an order" on order_vendor_groups
  for select using (
    order_id in (select id from orders where buyer_id = (select auth.uid()))
    or vendor_id in (select id from vendors where owner_id = (select auth.uid()))
  );
create policy "Vendors update fulfillment status of their group" on order_vendor_groups
  for update using (vendor_id in (select id from vendors where owner_id = (select auth.uid())));

alter table order_items enable row level security;
create policy "Buyer or vendor can see the relevant order items" on order_items
  for select using (
    order_vendor_group_id in (
      select id from order_vendor_groups
      where order_id in (select id from orders where buyer_id = (select auth.uid()))
         or vendor_id in (select id from vendors where owner_id = (select auth.uid()))
    )
  );

alter table reviews enable row level security;
create policy "Reviews are public" on reviews for select using (true);
create policy "Signed-in users write their own review" on reviews
  for insert with check ((select auth.uid()) = user_id);
create policy "Users edit their own review" on reviews for update using ((select auth.uid()) = user_id);
