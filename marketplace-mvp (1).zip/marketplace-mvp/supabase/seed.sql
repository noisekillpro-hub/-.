-- ============================================================================
-- SEED DATA — safe to run right after the migration, before any user exists.
-- Categories don't depend on auth.users, so they can go in first.
-- Demo vendors/products depend on a real profile — see
-- supabase/demo-vendor-template.sql for that step.
-- ============================================================================

insert into categories (id, parent_id, name, slug, sort_order) values
  ('11111111-0000-0000-0000-000000000001', null, 'Електроніка', 'electronics', 1),
  ('11111111-0000-0000-0000-000000000002', null, 'Побутова техніка', 'appliances', 2),
  ('11111111-0000-0000-0000-000000000003', null, 'Одяг і взуття', 'fashion', 3),
  ('11111111-0000-0000-0000-000000000004', null, 'Дім і сад', 'home-garden', 4);

insert into categories (parent_id, name, slug, sort_order) values
  ('11111111-0000-0000-0000-000000000001', 'Смартфони', 'smartphones', 1),
  ('11111111-0000-0000-0000-000000000001', 'Ноутбуки', 'laptops', 2),
  ('11111111-0000-0000-0000-000000000001', 'Навушники', 'headphones', 3),
  ('11111111-0000-0000-0000-000000000002', 'Холодильники', 'fridges', 1),
  ('11111111-0000-0000-0000-000000000002', 'Пральні машини', 'washing-machines', 2),
  ('11111111-0000-0000-0000-000000000003', 'Чоловічий одяг', 'mens-clothing', 1),
  ('11111111-0000-0000-0000-000000000003', 'Жіночий одяг', 'womens-clothing', 2);
