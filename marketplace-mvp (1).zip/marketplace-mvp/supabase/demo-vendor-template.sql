-- ============================================================================
-- DEMO VENDOR + PRODUCTS — run this AFTER you've signed up one test account.
--
-- 1. Sign up through your running app (or Supabase Dashboard → Authentication
--    → Add user).
-- 2. Copy that user's UUID from Authentication → Users.
-- 3. Paste it in place of PASTE_USER_ID_HERE below, then run this whole file
--    in the Supabase SQL editor.
-- ============================================================================

with new_vendor as (
  insert into vendors (owner_id, name, slug, description, status, rating)
  values (
    'PASTE_USER_ID_HERE',
    'Тестовий магазин',
    'test-shop',
    'Демонстраційний продавець для перевірки маркетплейсу.',
    'approved',
    4.8
  )
  returning id
),
product_data(cat_slug, name, slug, description, price, compare_at_price, stock_quantity, rating, reviews_count) as (
  values
    ('smartphones', 'Смартфон Aurora X12 128GB', 'aurora-x12-128gb', 'Флагманський смартфон із яскравим дисплеєм і потужною камерою.', 18999.00, 20999.00, 24, 4.7, 132),
    ('laptops', 'Ноутбук Nova Book 14"', 'nova-book-14', 'Легкий ноутбук для роботи й навчання, 16 ГБ ОЗП.', 27999.00, null, 11, 4.6, 58),
    ('headphones', 'Бездротові навушники SoundWave Pro', 'soundwave-pro', 'Активне шумозаглушення, до 30 годин роботи.', 3499.00, 3999.00, 60, 4.5, 214)
)
insert into products (vendor_id, category_id, name, slug, description, price, compare_at_price, stock_quantity, status, rating, reviews_count)
select
  new_vendor.id,
  categories.id,
  product_data.name,
  product_data.slug,
  product_data.description,
  product_data.price,
  product_data.compare_at_price,
  product_data.stock_quantity,
  'active',
  product_data.rating,
  product_data.reviews_count
from product_data
join categories on categories.slug = product_data.cat_slug
cross join new_vendor
returning name, slug, price;
