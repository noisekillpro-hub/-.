import ProductCard from "@/components/ProductCard";
import type { ProductWithRelations } from "@/lib/types";

export default function ProductGrid({ products }: { products: ProductWithRelations[] }) {
  if (products.length === 0) {
    return (
      <p className="rounded-card border border-dashed border-border py-16 text-center text-muted">
        Тут поки що немає товарів.
      </p>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
