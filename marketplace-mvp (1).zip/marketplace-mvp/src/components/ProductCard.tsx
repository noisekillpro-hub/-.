import Image from "next/image";
import Link from "next/link";
import { Package, Star } from "lucide-react";
import type { ProductWithRelations } from "@/lib/types";

const currency = new Intl.NumberFormat("uk-UA", {
  style: "currency",
  currency: "UAH",
  maximumFractionDigits: 0,
});

export default function ProductCard({ product }: { product: ProductWithRelations }) {
  const image = [...product.product_images].sort((a, b) => a.sort_order - b.sort_order)[0];
  const onSale = product.compare_at_price && product.compare_at_price > product.price;

  return (
    <Link
      href={`/product/${product.slug}`}
      className="group flex flex-col overflow-hidden rounded-card border border-border bg-white transition-shadow hover:shadow-md"
    >
      <div className="relative aspect-square w-full overflow-hidden bg-brand-light">
        {image ? (
          <Image
            src={image.url}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center">
            <Package className="h-10 w-10 text-brand/40" />
          </div>
        )}
        {onSale && (
          <span className="absolute left-2 top-2 rounded-full bg-accent px-2 py-0.5 text-xs font-semibold text-white">
            Знижка
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-1.5 p-3">
        {product.vendors && (
          <span className="inline-flex w-fit items-center gap-1.5 text-xs text-muted">
            <span className="flex h-4 w-4 items-center justify-center rounded-full bg-brand text-[9px] font-bold text-white">
              {product.vendors.name.charAt(0).toUpperCase()}
            </span>
            {product.vendors.name}
          </span>
        )}

        <h3 className="line-clamp-2 font-medium leading-snug text-ink">{product.name}</h3>

        <div className="mt-auto flex items-center justify-between pt-1">
          <div className="flex items-baseline gap-1.5">
            <span className="font-display font-bold text-ink">{currency.format(product.price)}</span>
            {onSale && (
              <span className="text-xs text-muted line-through">{currency.format(product.compare_at_price!)}</span>
            )}
          </div>
          {product.reviews_count > 0 && (
            <span className="flex items-center gap-0.5 text-xs text-muted">
              <Star className="h-3.5 w-3.5 fill-accent text-accent" />
              {product.rating.toFixed(1)}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
