import Link from "next/link";
import type { CategoryRow } from "@/lib/types";

export default function CategoryNav({ categories }: { categories: CategoryRow[] }) {
  if (categories.length === 0) return null;

  return (
    <nav aria-label="Категорії" className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 py-4 sm:mx-0 sm:px-0">
      {categories.map((category) => (
        <Link
          key={category.id}
          href={`/category/${category.slug}`}
          className="shrink-0 rounded-full border border-border bg-white px-4 py-2 text-sm font-medium text-ink transition-colors hover:border-brand hover:text-brand-dark"
        >
          {category.name}
        </Link>
      ))}
    </nav>
  );
}
