import Link from "next/link";
import { Search, ShoppingCart, User } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { signOut } from "@/lib/supabase/actions";

export default async function Header() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="shrink-0 font-display text-xl font-bold tracking-tight text-brand">
          ринок<span className="text-accent">.</span>
        </Link>

        <div className="relative hidden flex-1 sm:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input
            type="search"
            placeholder="Шукати товари, категорії, продавців…"
            disabled
            title="Пошук з'явиться на наступному етапі"
            className="w-full rounded-full border border-border bg-white py-2 pl-9 pr-4 text-sm text-ink placeholder:text-muted disabled:cursor-not-allowed disabled:opacity-70"
          />
        </div>

        <div className="ml-auto flex items-center gap-1 sm:ml-0">
          {user ? (
            <>
              <Link
                href="/become-vendor"
                title="Ваш акаунт / стати продавцем"
                className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm text-ink/80 hover:bg-brand-light hover:text-brand-dark"
              >
                <User className="h-5 w-5" />
                <span className="hidden max-w-[10rem] truncate md:inline">
                  {(user.user_metadata?.full_name as string | undefined) || user.email}
                </span>
              </Link>
              <form action={signOut}>
                <button
                  type="submit"
                  className="rounded-full px-3 py-2 text-sm text-ink/80 hover:bg-brand-light hover:text-brand-dark"
                >
                  Вийти
                </button>
              </form>
            </>
          ) : (
            <Link
              href="/login"
              className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm text-ink/80 hover:bg-brand-light hover:text-brand-dark"
            >
              <User className="h-5 w-5" />
              <span className="hidden md:inline">Увійти</span>
            </Link>
          )}
          <button
            type="button"
            title="Кошик з'явиться на наступному етапі"
            className="relative flex items-center gap-1.5 rounded-full px-3 py-2 text-sm text-ink/80 hover:bg-brand-light hover:text-brand-dark"
          >
            <ShoppingCart className="h-5 w-5" />
            <span className="hidden md:inline">Кошик</span>
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-semibold text-white">
              0
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
