import Link from "next/link";
import { signIn } from "@/lib/supabase/actions";

export const dynamic = "force-dynamic";

const inputClass =
  "rounded-lg border border-border bg-white px-3 py-2 text-ink focus:border-brand focus:outline-none";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="mx-auto max-w-sm py-16">
      <h1 className="font-display text-2xl font-bold text-ink">Вхід</h1>

      {error && (
        <p className="mt-4 rounded-lg bg-accent-light px-4 py-3 text-sm text-accent-dark">{error}</p>
      )}

      <form action={signIn} className="mt-6 flex flex-col gap-4">
        <label className="flex flex-col gap-1 text-sm text-ink">
          Email
          <input type="email" name="email" required className={inputClass} />
        </label>
        <label className="flex flex-col gap-1 text-sm text-ink">
          Пароль
          <input type="password" name="password" required minLength={6} className={inputClass} />
        </label>
        <button
          type="submit"
          className="mt-2 rounded-full bg-brand py-2.5 font-semibold text-white transition-colors hover:bg-brand-dark"
        >
          Увійти
        </button>
      </form>

      <p className="mt-4 text-sm text-muted">
        Ще нема акаунту?{" "}
        <Link href="/register" className="text-brand-dark hover:underline">
          Зареєструватись
        </Link>
      </p>
    </div>
  );
}
