import { createClient } from "@/lib/supabase/server";
import CategoryNav from "@/components/CategoryNav";
import ProductGrid from "@/components/ProductGrid";
import type { CategoryRow, ProductWithRelations } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const supabase = await createClient();

  const [categoriesResult, productsResult] = await Promise.all([
    supabase.from("categories").select("*").is("parent_id", null).order("sort_order"),
    supabase
      .from("products")
      .select("*, product_images(url, sort_order), vendors(name, slug, rating)")
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(12),
  ]);

  if (categoriesResult.error || productsResult.error) {
    return (
      <div className="mx-auto mt-16 max-w-lg rounded-card border border-border bg-white p-6 text-center">
        <h1 className="font-display text-lg font-semibold text-ink">Немає з&apos;єднання з Supabase</h1>
        <p className="mt-2 text-sm text-muted">
          Перевірте, що <code className="rounded bg-brand-light px-1 py-0.5">.env.local</code> заповнено і що
          міграція <code className="rounded bg-brand-light px-1 py-0.5">0001_init.sql</code> виконана у вашому
          проєкті Supabase. Деталі — у README.md.
        </p>
      </div>
    );
  }

  const topCategories = (categoriesResult.data ?? []) as CategoryRow[];
  const featuredProducts = (productsResult.data ?? []) as unknown as ProductWithRelations[];

  return (
    <div className="pb-16">
      <CategoryNav categories={topCategories} />

      <section className="mt-4">
        <h1 className="font-display text-2xl font-bold text-ink">Популярні товари</h1>
        <p className="mt-1 text-sm text-muted">Від різних продавців маркетплейсу, найновіші спочатку.</p>
        <div className="mt-6">
          <ProductGrid products={featuredProducts} />
        </div>
      </section>
    </div>
  );
}
