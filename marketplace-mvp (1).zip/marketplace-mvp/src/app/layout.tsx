import type { Metadata } from "next";
import { Inter, Unbounded } from "next/font/google";
import Header from "@/components/Header";
import "./globals.css";

const inter = Inter({ subsets: ["latin", "cyrillic"], variable: "--font-inter" });
const unbounded = Unbounded({ subsets: ["latin", "cyrillic"], variable: "--font-unbounded" });

export const metadata: Metadata = {
  title: "Маркетплейс — все від багатьох продавців в одному місці",
  description: "Навчальний проєкт: багатопродавцевий маркетплейс на Next.js + Supabase.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uk" className={`${inter.variable} ${unbounded.variable}`}>
      <body className="font-sans">
        <Header />
        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">{children}</main>
        <footer className="mt-16 border-t border-border py-8 text-center text-sm text-muted">
          Навчальний проєкт маркетплейсу. Не є реальним магазином.
        </footer>
      </body>
    </html>
  );
}
