import { notFound } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import ProductGrid from "@/components/ProductGrid";
import type { CategoryRow, ProductWithRelations } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: category } = await supabase.from("categories").select("*").eq("slug", slug).single();

  if (!category) notFound();

  const { data: children } = await supabase
    .from("categories")
    .select("*")
    .eq("parent_id", category.id)
    .order("sort_order");

  const childCategories = (children ?? []) as CategoryRow[];
  const categoryIds = [category.id, ...childCategories.map((child) => child.id)];

  const { data: products } = await supabase
    .from("products")
    .select("*, product_images(url, sort_order), vendors(name, slug, rating)")
    .in("category_id", categoryIds)
    .eq("status", "active")
    .order("created_at", { ascending: false });

  const categoryProducts = (products ?? []) as unknown as ProductWithRelations[];

  return (
    <div className="pb-16">
      <nav className="pt-4 text-sm text-muted">
        <Link href="/" className="hover:text-brand-dark">
          Головна
        </Link>{" "}
        / {category.name}
      </nav>

      <h1 className="mt-2 font-display text-2xl font-bold text-ink">{category.name}</h1>

      {childCategories.length > 0 && (
        <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto">
          {childCategories.map((child) => (
            <Link
              key={child.id}
              href={`/category/${child.slug}`}
              className="shrink-0 rounded-full border border-border bg-white px-3 py-1.5 text-sm text-ink hover:border-brand hover:text-brand-dark"
            >
              {child.name}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-6">
        <ProductGrid products={categoryProducts} />
      </div>
    </div>
  );
}
