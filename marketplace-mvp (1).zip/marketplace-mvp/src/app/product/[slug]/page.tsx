import { notFound } from "next/navigation";
import Image from "next/image";
import { Package, Star } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import type { ProductWithRelations } from "@/lib/types";

export const dynamic = "force-dynamic";

const currency = new Intl.NumberFormat("uk-UA", {
  style: "currency",
  currency: "UAH",
  maximumFractionDigits: 0,
});

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: product } = await supabase
    .from("products")
    .select("*, product_images(url, sort_order), vendors(name, slug, rating)")
    .eq("slug", slug)
    .eq("status", "active")
    .single();

  if (!product) notFound();

  const typedProduct = product as unknown as ProductWithRelations;
  const images = [...typedProduct.product_images].sort((a, b) => a.sort_order - b.sort_order);
  const onSale = typedProduct.compare_at_price && typedProduct.compare_at_price > typedProduct.price;

  const { data: reviews } = await supabase
    .from("reviews")
    .select("*")
    .eq("product_id", typedProduct.id)
    .order("created_at", { ascending: false })
    .limit(10);

  return (
    <div className="grid gap-8 pb-16 pt-6 md:grid-cols-2">
      <div className="aspect-square overflow-hidden rounded-card bg-brand-light">
        {images[0] ? (
          <div className="relative h-full w-full">
            <Image src={images[0].url} alt={typedProduct.name} fill className="object-cover" />
          </div>
        ) : (
          <div className="flex h-full items-center justify-center">
            <Package className="h-16 w-16 text-brand/40" />
          </div>
        )}
      </div>

      <div>
        {typedProduct.vendors && (
          <span
            className="inline-flex items-center gap-1.5 text-sm text-muted"
            title="Сторінки продавців з'являться на наступному етапі"
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-white">
              {typedProduct.vendors.name.charAt(0).toUpperCase()}
            </span>
            Продає {typedProduct.vendors.name}
          </span>
        )}

        <h1 className="mt-2 font-display text-2xl font-bold text-ink">{typedProduct.name}</h1>

        {typedProduct.reviews_count > 0 && (
          <div className="mt-2 flex items-center gap-1.5 text-sm text-muted">
            <Star className="h-4 w-4 fill-accent text-accent" />
            {typedProduct.rating.toFixed(1)} · {typedProduct.reviews_count} відгуків
          </div>
        )}

        <div className="mt-4 flex items-baseline gap-2">
          <span className="font-display text-3xl font-bold text-ink">{currency.format(typedProduct.price)}</span>
          {onSale && (
            <span className="text-muted line-through">{currency.format(typedProduct.compare_at_price!)}</span>
          )}
        </div>

        <p className="mt-1 text-sm text-stock">
          {typedProduct.stock_quantity > 0 ? `В наявності: ${typedProduct.stock_quantity} шт.` : "Немає в наявності"}
        </p>

        <button
          type="button"
          disabled
          title="Кошик з'явиться на наступному етапі"
          className="mt-6 w-full rounded-full bg-accent py-3 font-semibold text-white transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
        >
          Додати в кошик
        </button>

        {typedProduct.description && (
          <p className="mt-6 whitespace-pre-line leading-relaxed text-ink/80">{typedProduct.description}</p>
        )}

        <div className="mt-10 border-t border-border pt-6">
          <h2 className="font-display text-lg font-semibold text-ink">Відгуки</h2>
          {!reviews || reviews.length === 0 ? (
            <p className="mt-2 text-sm text-muted">Ще немає відгуків.</p>
          ) : (
            <ul className="mt-4 space-y-4">
              {reviews.map((review) => (
                <li key={review.id} className="border-b border-border pb-4 last:border-0">
                  <div className="flex items-center gap-2 text-sm font-medium text-ink">
                    <Star className="h-3.5 w-3.5 fill-accent text-accent" />
                    {review.rating}/5
                  </div>
                  {review.comment && <p className="mt-1 text-sm text-ink/80">{review.comment}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
