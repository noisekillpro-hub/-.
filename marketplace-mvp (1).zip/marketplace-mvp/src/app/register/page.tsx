import Link from "next/link";
import { signUp } from "@/lib/supabase/actions";

export const dynamic = "force-dynamic";

const inputClass =
  "rounded-lg border border-border bg-white px-3 py-2 text-ink focus:border-brand focus:outline-none";

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const { error, success } = await searchParams;

  if (success === "check-email") {
    return (
      <div className="mx-auto max-w-sm py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-ink">Перевірте пошту</h1>
        <p className="mt-2 text-muted">
          Ми надіслали лист для підтвердження акаунту. Перейдіть за посиланням у ньому, а потім
          увійдіть.
        </p>
        <Link href="/login" className="mt-4 inline-block text-brand-dark hover:underline">
          До входу
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-sm py-16">
      <h1 className="font-display text-2xl font-bold text-ink">Реєстрація</h1>

      {error && (
        <p className="mt-4 rounded-lg bg-accent-light px-4 py-3 text-sm text-accent-dark">{error}</p>
      )}

      <form action={signUp} className="mt-6 flex flex-col gap-4">
        <label className="flex flex-col gap-1 text-sm text-ink">
          Ім&apos;я
          <input type="text" name="fullName" required className={inputClass} />
        </label>
        <label className="flex flex-col gap-1 text-sm text-ink">
          Email
          <input type="email" name="email" required className={inputClass} />
        </label>
        <label className="flex flex-col gap-1 text-sm text-ink">
          Пароль
          <input type="password" name="password" required minLength={6} className={inputClass} />
        </label>
        <button
          type="submit"
          className="mt-2 rounded-full bg-brand py-2.5 font-semibold text-white transition-colors hover:bg-brand-dark"
        >
          Зареєструватись
        </button>
      </form>

      <p className="mt-4 text-sm text-muted">
        Вже є акаунт?{" "}
        <Link href="/login" className="text-brand-dark hover:underline">
          Увійти
        </Link>
      </p>
    </div>
  );
}
