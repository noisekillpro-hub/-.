import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createVendor } from "@/lib/supabase/actions";

export const dynamic = "force-dynamic";

const inputClass =
  "rounded-lg border border-border bg-white px-3 py-2 text-ink focus:border-brand focus:outline-none";

const statusLabels: Record<string, string> = {
  pending: "на розгляді",
  approved: "схвалено",
  suspended: "заблоковано",
};

export default async function BecomeVendorPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect(`/login?error=${encodeURIComponent("Спершу увійдіть в акаунт")}`);
  }

  const { data: vendor } = await supabase.from("vendors").select("*").eq("owner_id", user.id).single();

  if (vendor) {
    return (
      <div className="mx-auto max-w-sm py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-ink">У вас уже є магазин</h1>
        <p className="mt-2 text-muted">
          «{vendor.name}» — статус: {statusLabels[vendor.status] ?? vendor.status}
        </p>
        <p className="mt-4 text-sm text-muted">
          Додавання товарів і кабінет продавця — наступна фаза.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-sm py-16">
      <h1 className="font-display text-2xl font-bold text-ink">Стати продавцем</h1>
      <p className="mt-2 text-sm text-muted">Заповніть базову інформацію про магазин.</p>

      {error && (
        <p className="mt-4 rounded-lg bg-accent-light px-4 py-3 text-sm text-accent-dark">{error}</p>
      )}

      <form action={createVendor} className="mt-6 flex flex-col gap-4">
        <label className="flex flex-col gap-1 text-sm text-ink">
          Назва магазину
          <input type="text" name="name" required className={inputClass} />
        </label>
        <label className="flex flex-col gap-1 text-sm text-ink">
          Опис (необов&apos;язково)
          <textarea name="description" rows={3} className={inputClass} />
        </label>
        <button
          type="submit"
          className="mt-2 rounded-full bg-accent py-2.5 font-semibold text-white transition-colors hover:bg-accent-dark"
        >
          Створити магазин
        </button>
      </form>
    </div>
  );
}
