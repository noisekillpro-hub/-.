"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function signIn(formData: FormData) {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    redirect(`/login?error=${encodeURIComponent(error.message)}`);
  }

  redirect("/");
}

export async function signUp(formData: FormData) {
  const fullName = formData.get("fullName") as string;
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { full_name: fullName } },
  });

  if (error) {
    redirect(`/register?error=${encodeURIComponent(error.message)}`);
  }

  // If the project requires email confirmation, signUp() succeeds but
  // returns no session yet — send them to check their inbox instead of
  // pretending they're logged in.
  if (!data.session) {
    redirect("/register?success=check-email");
  }

  redirect("/");
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}

export async function createVendor(formData: FormData) {
  const name = (formData.get("name") as string)?.trim();
  const description = (formData.get("description") as string)?.trim();

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect(`/login?error=${encodeURIComponent("Спершу увійдіть в акаунт")}`);
  }

  // Simple, ASCII-only slug — good enough while there's no public vendor
  // page yet (it only has to be unique). A nicer transliterated/editable
  // slug is a fine follow-up once /vendor/[slug] pages exist.
  const baseSlug = name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
  const slug = `${baseSlug || "shop"}-${user.id.slice(0, 8)}`;

  const { error } = await supabase.from("vendors").insert({
    owner_id: user.id,
    name,
    slug,
    description: description || null,
  });

  if (error) {
    redirect(`/become-vendor?error=${encodeURIComponent(error.message)}`);
  }

  // Best-effort — vendor creation already succeeded even if this fails.
  await supabase.from("profiles").update({ role: "vendor" }).eq("id", user.id);

  redirect("/become-vendor");
}
